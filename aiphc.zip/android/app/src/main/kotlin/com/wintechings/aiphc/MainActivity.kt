package com.wintechings.aiphc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
