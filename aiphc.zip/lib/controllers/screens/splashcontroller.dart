import 'package:get/get.dart';

class SplashController extends GetxController {
  @override
  void onInit() {
    super.onInit();

    Future.delayed(const Duration(seconds: 3), () {
      // TODO: auth check later
      Get.offAllNamed('/login'); // or '/dashboard'
    });
  }
}
