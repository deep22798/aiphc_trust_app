class Appconstants {
  static String applogo="assets/images/logo.png";
  static String loginbackground="assets/images/loginback.jpg";
  static String loginbackground2="assets/images/loginbak1.png";
}


